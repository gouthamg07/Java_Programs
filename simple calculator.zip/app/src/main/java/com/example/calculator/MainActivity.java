package com.example.calcipractise;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AppComponentFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends AppComponentFactory {
    EditText num1, num2;
    TextView res;
    char op;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        num1 = findViewById(R.id.number1);
        num2 = findViewById(R.id.number2);
        res = findViewById(R.id.result);
    }

public void one(View view) {
    if (num1.hasFocus()) {
        num1.append("1");

    } else if (num2.hasFocus()) {
        num2.append("1");
    }
}

    public void two(View V) {
        if (num1.hasFocus()) {
            num1.append("2");
        } else if (num2.hasFocus()) {
            num2.append("2");
        }
    }

    public void three(View V) {
        if (num1.hasFocus()) {
            num1.append("3");
        } else if (num2.hasFocus()) {
            num2.append("3");
        }
    }

    public void four(View V) {
        if (num1.hasFocus()) {
            num1.append("4");
        } else if (num2.hasFocus()) {
            num2.append("4");
        }
    }

    public void five(View V) {
        if (num1.hasFocus()) {
            num1.append("5");
        } else if (num2.hasFocus()) {
            num2.append("5");
        }
    }

    public void six(View V) {
        if (num1.hasFocus()) {
            num1.append("6");
        } else if (num2.hasFocus()) {
            num2.append("6");
        }
    }

    public void seven(View V) {
        if (num1.hasFocus()) {
            num1.append("7");
        } else if (num2.hasFocus()) {
            num2.append("7");
        }
    }

    public void eight(View V) {
        if (num1.hasFocus()) {
            num1.append("8");
        } else if (num2.hasFocus()) {
            num2.append("8");
        }
    }

    public void nine(View V) {
        if (num1.hasFocus()) {
            num1.append("9");
        } else if (num2.hasFocus()) {
            num2.append("9");
        }
    }

    public void zero(View V) {
        if (num1.hasFocus()) {
            num1.append("0");
        } else if (num2.hasFocus()) {
            num2.append("0");
        }
    }

    public void dot(View V) {
        if (num1.hasFocus()) {
            num1.append(".");
        } else if (num2.hasFocus()) {
            num2.append(".");
        }
    }

    public void add(View V)
    {
        op = '+';
    }

    public void sub(View V)
    {
        op = '-';
    }

    public void mul(View V)
    {
        op = '*';
    }

    public void div(View V)
    {
        op = '/';
    }

    public void compute(View V)
    {
        float n1, n2, r;
        switch (op) {
            case '+':
                n1 = Float.parseFloat(num1.getText().toString());
                n2 = Float.parseFloat(num2.getText().toString());
                r = n1 + n2;
                res.setText(" "+n1+" "+n2+" "+"="+ r);
                break;
            case '-':
                n1 = Float.parseFloat(num1.getText().toString());
                n2 = Float.parseFloat(num2.getText().toString());
                r = n1 - n2;
                res.setText("" + n1 + "-" + n2 + "=" + r);
                break;
            case '*':
                n1 = Float.parseFloat(num1.getText().toString());
                n2 = Float.parseFloat(num2.getText().toString());
                r = n1 * n2;
                res.setText("" + n1 + "*" + n2 + "=" + r);
                break;
            case '/':
                n1 = Float.parseFloat(num1.getText().toString());
                n2 = Float.parseFloat(num2.getText().toString());
                r = n1 / n2;
                res.setText("" + n1 + "/" + n2 + "=" + r);
                break;
        }
    }
    public void all_clear(View V){
        num1.setText(" ");
        num2.setText(" ");
        res.setText(" ");
    }

    public  void clear_one_field(View v){
        if(num1.hasFocus()){
            num1.setText(" ");
                 res.setText(" ");}
            else if (num2.hasFocus()){
              num2.setText(" ");
              res.setText(" ");
            }
    }

    public void clear_one_digit(View V){
        if(num1.hasFocus()){
            String n;
            n = num1.getText().toString();
            n = n.substring(0,n.length()-1);
            num1.setText(n);

        }
        else if (num2.hasFocus()){
            String n;
            n = num1.getText().toString();
            n = n.substring(0,n.length()-1);
            num2.setText(n);
        }
    }


}



